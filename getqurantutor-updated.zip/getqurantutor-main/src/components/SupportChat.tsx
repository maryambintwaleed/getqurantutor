"use client";

import { useState, useRef, useEffect } from "react";
import { MessageCircle, X, Send } from "lucide-react";

type Message = {
  from: "user" | "support";
  text: string;
};

const AUTO_REPLIES: Record<string, string> = {
  default:
    "Thanks for reaching out! Our team will get back to you shortly. For urgent queries, email us at support@getqurantutor.com",
  teacher:
    "To find a Quran teacher, simply pick a course on our homepage and fill in a short form. Verified teachers will send you their plan within hours!",
  price:
    "GetQuranTutor is completely free for families. Teachers set their own rates and send you a quote — you only pay the teacher directly.",
  register:
    "To register as a teacher, click 'Become a teacher' on the homepage and create your free profile. You'll get 20 free credits to start!",
  verify:
    "Teacher verification includes an ID check and a voice recitation review. This keeps families safe and ensures quality.",
};

function getAutoReply(text: string): string {
  const lower = text.toLowerCase();
  if (lower.includes("teacher") || lower.includes("tutor") || lower.includes("find"))
    return AUTO_REPLIES.teacher;
  if (lower.includes("price") || lower.includes("cost") || lower.includes("fee") || lower.includes("pay"))
    return AUTO_REPLIES.price;
  if (lower.includes("register") || lower.includes("sign up") || lower.includes("join"))
    return AUTO_REPLIES.register;
  if (lower.includes("verify") || lower.includes("verification") || lower.includes("check"))
    return AUTO_REPLIES.verify;
  return AUTO_REPLIES.default;
}

export default function SupportChat() {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<Message[]>([
    {
      from: "support",
      text: "Assalamu alaikum! 👋 How can we help you today?",
    },
  ]);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (open) bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, open]);

  function send() {
    const text = input.trim();
    if (!text) return;
    setMessages((prev) => [...prev, { from: "user", text }]);
    setInput("");
    setTimeout(() => {
      setMessages((prev) => [
        ...prev,
        { from: "support", text: getAutoReply(text) },
      ]);
    }, 800);
  }

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end gap-3">
      {/* Chat window */}
      {open && (
        <div className="flex h-[420px] w-[320px] flex-col overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl">
          {/* Header */}
          <div className="flex items-center justify-between bg-brand-800 px-4 py-3">
            <div className="flex items-center gap-2">
              <span className="flex h-8 w-8 items-center justify-center rounded-full bg-white/20 text-sm">
                🕌
              </span>
              <div>
                <p className="text-sm font-semibold text-white">Support</p>
                <p className="text-xs text-brand-200">GetQuranTutor</p>
              </div>
            </div>
            <button
              onClick={() => setOpen(false)}
              className="text-white/70 hover:text-white transition"
              aria-label="Close chat"
            >
              <X size={18} />
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto space-y-3 p-4">
            {messages.map((msg, i) => (
              <div
                key={i}
                className={`flex ${msg.from === "user" ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`max-w-[80%] rounded-2xl px-3 py-2 text-sm leading-snug ${
                    msg.from === "user"
                      ? "bg-brand-700 text-white rounded-br-sm"
                      : "bg-slate-100 text-slate-700 rounded-bl-sm"
                  }`}
                >
                  {msg.text}
                </div>
              </div>
            ))}
            <div ref={bottomRef} />
          </div>

          {/* Input */}
          <div className="flex items-center gap-2 border-t border-slate-100 px-3 py-3">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && send()}
              placeholder="Type a message…"
              className="flex-1 rounded-full border border-slate-200 px-3 py-1.5 text-sm outline-none focus:border-brand-400"
            />
            <button
              onClick={send}
              disabled={!input.trim()}
              className="flex h-8 w-8 items-center justify-center rounded-full bg-brand-700 text-white transition hover:bg-brand-600 disabled:opacity-40"
              aria-label="Send"
            >
              <Send size={14} />
            </button>
          </div>
        </div>
      )}

      {/* Toggle button */}
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex h-14 w-14 items-center justify-center rounded-full bg-brand-700 text-white shadow-lg transition hover:bg-brand-600 hover:scale-105"
        aria-label="Open support chat"
      >
        {open ? <X size={22} /> : <MessageCircle size={22} />}
      </button>
    </div>
  );
}
